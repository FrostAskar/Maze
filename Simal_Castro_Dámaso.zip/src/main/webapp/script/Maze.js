const canvas = document.getElementById('mazeCanvas');
const ctx = canvas.getContext('2d');
ctx.font = "24px Verdana";
console.log(document.getElementById('jsonInput'));
let jsonMazeObject = JSON.parse(document.getElementById('jsonInput').textContent);
let previousTimestamp;
let victory = false;

//Values for frames/second
let numberOfSprites = 8
let animationDurationInMiliseconds = 3000;
let framesecond = animationDurationInMiliseconds / numberOfSprites; 
let animationStart;

const step = (timestamp) => {
    // previousTimestamp = timestamp;

    /*
        Hay que generar una manera en la que obtengamos el número de milisegundos que debe estar cada sprite, tras eso
        if (timestamp - previoustimestamp > (calculo de (duración animación / número de frames) * 1/60)) {Pinta siguiente frame}
    */
   //Interior: Selección de frame a pintar
    //if (timestamp - animationStart  >= framesecond ) {
        jsonMazeObject = JSON.parse(document.getElementById('jsonInput').textContent);
        generateRoom();
        drawKeyControls();
        placePC();
        //aumentarOffset();
        placeCoin();
        placeKey();
        checkVictory();
        if (victory){
            writeMessage("You've beat the maze");
        }
    //}

    //Exterior, cálculo de posición del sprite

    requestAnimationFrame(step);
}

function writeMessage(message) {
    ctx.clearRect(roomOriginX, roomOriginY-50, roomWidth, 50);
    ctx.fillStyle = "gray";
    ctx.fillText(message, roomOriginX + 50, roomOriginY - 50);
}

function checkVictory() {
    if (jsonMazeObject.victory) {
        victory = true;
    }
}

requestAnimationFrame(step);

//Room Dimensions
const roomHeight = 400
const roomWidth = 400;
const roomDoorHeight = roomHeight/16;
const roomDoorWidth = roomWidth/16

//Sprite Dimensions
const pcHeight = 33;
const pcWidth = 32;
const rupeeOriginalHeight = 20;
const rupeeOriginalWidth = 20;
const rupeeResizeHeight = 33;
const rupeeResizeWidth = 32;
const keyHeight = 33;
const keyWidth = 32;

//Spritesheet Positions
let pcCol = 0;
let pcRow = 0;
let rupeeCol = 0;
let rupeeRow = 0;

//Room reference positions
const roomOriginX = 200;
const roomOriginY = 200;
let pcPositionX = 380;
let pcPositionY = 380;
let rupeePositionX, rupeePositionY, keyPositionX, keyPositionY;

const linkImage = new Image();
linkImage.src = "/images/LinkWalkCycle.png";
const rupeeImage = new Image();
rupeeImage.src = "/images/RupeeSheet.png";
const keyImage = new Image();
keyImage.src = "/images/Key.png";
const arrowKeys = new Image();
arrowKeys.src = "/images/ArrowKeys.png"

const imageSet = [linkImage, rupeeImage, keyImage, arrowKeys];
let imageCount = 0;

imageSet.forEach((image) => {
    image.onload = () => {
        imageCount++;
        if (imageCount == imageSet.length){
            drawRoom();
        }
    }
});

function drawKeyControls() {
    ctx.drawImage(arrowKeys, 700,400)
}

function press(dir){
    switch(dir){
        case "up":
            if (jsonMazeObject.doors.N == "closed") {
                writeMessage("This door is currently closed");
            } else if (jsonMazeObject.doors.N == "wall") {
                writeMessage("There is no door on this side!");
            } else {
            window.location.href = "/nav?dir=N";
            }
            break;
        case "down":
            if (jsonMazeObject.doors.S == "closed") {
                writeMessage("This door is currently closed");
            } else if (jsonMazeObject.doors.S == "wall") {
                writeMessage("There is no door on this side!");
            } else {
            window.location.href = "/nav?dir=S";
            }
            break;
        case "left":
            if (jsonMazeObject.doors.W == "closed") {
                writeMessage("This door is currently closed");
            } else if (jsonMazeObject.doors.W == "wall") {
                writeMessage("There is no door on this side!");
            } else {
            window.location.href = "/nav?dir=W";
            }
            break;
        case "right":
            if (jsonMazeObject.doors.E == "closed") {
                writeMessage("This door is currently closed");
            } else if (jsonMazeObject.doors.E == "wall") {
                writeMessage("There is no door on this side!");
            } else {
            window.location.href = "/nav?dir=E";
            }
            break;
    }
    console.log(dir + " key was pressed");
}

function openDoor(x, y){
    if (x >= northDoor[0] && x <= northDoor[0] + roomDoorWidth &&
        y >= northDoor[1] && y <= northDoor[1] + roomDoorHeight &&
        jsonMazeObject.doors.N == "closed"){
        window.location.href = "/open?dir=N";
        console.log("North Door Clicked");
    } else if (x >= southDoor[0] && x <= southDoor[0] + roomDoorWidth &&
        y >= southDoor[1] && y <= southDoor[1] + roomDoorHeight &&
        jsonMazeObject.doors.S == "closed"){
        window.location.href = "/open?dir=S";
        console.log("South Door Clicked");
    } else if (x >= westDoor[0] && x <= westDoor[0] + roomDoorWidth &&
        y >= westDoor[1] && y <= westDoor[1] + roomDoorHeight &&
        jsonMazeObject.doors.W == "closed"){
        window.location.href = "/open?dir=W";
        console.log("West Door Clicked");
    } else if (x >= eastDoor[0] && x <= eastDoor[0] + roomDoorWidth &&
        y >= eastDoor[1] && y <= eastDoor[1] + roomDoorHeight &&
        jsonMazeObject.doors.E == "closed"){
        window.location.href = "/open?dir=E";
        console.log("East Door Clicked");
    }
}

const doors = Object.entries(jsonMazeObject.doors);
console.log(doors);

const room = jsonMazeObject.room;
const inventory = jsonMazeObject.inventory;
const itemsInRoom = jsonMazeObject.items;

let collectedCoin = false;
let collectedKey = false;

const northDoor = [387, 200];
const westDoor = [200, 387];
const eastDoor = [575, 387];
const southDoor = [387, 575];

function drawWalls() {
    ctx.fillStyle = "black";
    ctx.fillRect(roomOriginX, roomOriginY, roomWidth, roomWidth);
    ctx.clearRect(roomOriginX + 25, roomOriginY + 25, roomWidth - 50, roomWidth -50);
}


function positionTranslator(direction) {
    switch(direction) {
        case "N":
            return northDoor;
        case "S":
            return southDoor;
        case "E":
            return eastDoor;
        case "W":
            return westDoor;
    };
}

function drawDoor(position, status) {
    if (status == "open"){
        ctx.clearRect(position[0], position[1], roomDoorWidth, roomDoorHeight);
    } else if (status == "closed") {
        ctx.fillStyle = "red";
        ctx.fillRect(position[0], position[1], roomDoorWidth, roomDoorHeight);
    } else if (status == "wall") {
        return;
    }
}

function drawDoors() {
    for (let i = 0; i < 4; i++) {
        drawDoor(positionTranslator(doors[i][0]), doors[i][1])
    }
}

function writeStatus() {
    ctx.fillStyle = "black";
    ctx.fillText("Room: " + room, 30, 30);
    ctx.fillText("Coins: " + inventory.coins, 30, 60);
    ctx.fillText("Keys: " + inventory.keys, 30, 90);
}


function placePC() {
    ctx.clearRect(pcPositionX, pcPositionY, pcWidth, pcHeight)
    ctx.drawImage(linkImage, pcCol*pcWidth, pcRow*pcHeight, pcWidth, pcHeight, pcPositionX, pcPositionY, pcWidth, pcHeight);
    pcCol++;
    if (pcCol == 10){
        pcCol = 0;
    }
}

function placeCoin() {
    if (jsonMazeObject.items.hasOwnProperty('coin')){
        rupeePositionX = roomOriginX + jsonMazeObject.items.coin.x * roomWidth;
        rupeePositionY = roomOriginY + jsonMazeObject.items.coin.y * roomHeight;
        ctx.clearRect(rupeePositionX, rupeePositionY, rupeeResizeWidth, rupeeResizeHeight);
        if (!collectedCoin){
            ctx.drawImage(rupeeImage, rupeeCol*rupeeOriginalWidth, rupeeRow*rupeeOriginalHeight, rupeeOriginalWidth, rupeeOriginalHeight, rupeePositionX, rupeePositionY, rupeeResizeWidth, rupeeResizeHeight);
        };
        rupeeCol++;
        if (rupeeCol == 3) {
            rupeeCol = 0;
            rupeeRow++
            if (rupeeRow == 4){
                rupeeRow = 0;
                rupeeCol = 0;
            }
        };
    }
}

function placeKey() {
    if (jsonMazeObject.items.hasOwnProperty('key')){
        keyPositionX = roomOriginX + jsonMazeObject.items.key.x * roomWidth;
        keyPositionY = roomOriginY + jsonMazeObject.items.key.y * roomHeight;
        if (!collectedKey){
            ctx.drawImage(keyImage, keyPositionX, keyPositionY, keyWidth, keyHeight);
        }
    }
}

function generateRoom() {
    drawWalls();
    drawDoors();
    writeStatus();

}

function generateOverlay() {
    placePC();
    placeCoin();
    placeKey();
}

function drawRoom() {
    generateRoom();
    generateOverlay();
}

//Mouse Detector
canvas.addEventListener("mousedown", function(event){
    const boundingRect = canvas.getBoundingClientRect();
    const mouseX = event.clientX - boundingRect.left;
    const mouseY = event.clientY - boundingRect.top;
    if (event.button == 0){
        console.log(mouseX);
        console.log(mouseY);
        if (!victory){
            collectCoin(mouseX, mouseY);
            collectKey(mouseX, mouseY);
            checkDir(mouseX, mouseY);
            openDoor(mouseX, mouseY);
        }
    } else if (event.button == 2){
        console.log("Right Mouse Button");
    }

});

//Key Detector
document.addEventListener("keydown", function(event){
    if (!victory){
        if(event.key === 'ArrowUp'){
            press("up");
        } else if (event.key === 'ArrowDown'){
            press("down");
        } else if (event.key === 'ArrowLeft'){
            press("left");
        } else if (event.key === 'ArrowRight'){
            press("right");
        }
    }
})

function collectCoin(x, y) {
    if (x >= rupeePositionX && x <= rupeePositionX + rupeeResizeWidth
        && y >= rupeePositionY && y <= rupeePositionY + rupeeResizeHeight
        && !collectedCoin) {
            writeMessage("You've collected a coin!")
            window.location.href = "/getcoin";
        };
}

function collectKey(x, y) {
    if (x >= keyPositionX && x <= keyPositionX + keyWidth
        && y >= keyPositionY && y <= keyPositionY + keyHeight
        && !collectedKey){
            writeMessage("You've collected a key!");
            window.location.href = "/getkey";
        }
}

function checkDir(x, y){
    if (x >= 796 && x <= 863 && y >= 462 && y <= 526) {
        press("up");
    } else if (x >= 868 && x <= 935 && y >= 532 && y <= 600) {
        press("right");
    } else if (x >= 725 && x <= 792 && y >= 532 && y <= 600) {
        press("left");
    } else if (x >= 797 && x <= 864 && y >= 532 && y <= 600) {
        press("down");
    }
}