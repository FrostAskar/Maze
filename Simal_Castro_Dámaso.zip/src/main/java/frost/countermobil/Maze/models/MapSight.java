package frost.countermobil.Maze.models;

public abstract class MapSight {
}
