package frost.countermobil.Maze.models;

public class Coin extends Item{

    //Default value, can work with it to implement different valued coins
    private int value = 1;

    public int getValue() {
        return value;
    }
}
