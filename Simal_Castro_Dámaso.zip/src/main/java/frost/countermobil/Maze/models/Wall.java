package frost.countermobil.Maze.models;

public class Wall extends MapSight{
}
