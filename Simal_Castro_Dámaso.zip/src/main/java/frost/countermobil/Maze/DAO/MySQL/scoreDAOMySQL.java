package frost.countermobil.Maze.DAO.MySQL;

import frost.countermobil.Maze.DAO.ScoreDAO;
import frost.countermobil.Maze.models.Player;

import java.util.List;

public class scoreDAOMySQL implements ScoreDAO {
    @Override
    public void savePlayerScore(Player player) {

    }

    @Override
    public List<Player> getTopPlayers() {
        return null;
    }

    @Override
    public Player getPlayer(int playerId) {
        return null;
    }
}
